module Leave_Management {
	requires java.base;
}